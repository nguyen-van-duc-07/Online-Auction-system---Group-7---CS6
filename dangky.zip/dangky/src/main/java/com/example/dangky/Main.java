package com.example.dangky;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.HashMap;
import java.util.Map;

public class Main extends Application {

    // 1. LƯU TÀI KHOẢN VÀ MẬT KHẨU
    public static Map<String, String> userDatabase = new HashMap<>();

    // 2. LƯU TÀI KHOẢN VÀ VAI TRÒ (Bidder/Seller)
    public static Map<String, String> userRoles = new HashMap<>();

    @Override
    public void start(Stage stage) throws Exception {
        Scene scene = new Scene(
                FXMLLoader.load(getClass().getResource("deptrai1.fxml"))
        );
        stage.setScene(scene);
        stage.setTitle("Đăng nhập");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}