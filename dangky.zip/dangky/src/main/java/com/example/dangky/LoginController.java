package com.example.dangky;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML private TextField txtLoginUser;
    @FXML private PasswordField txtLoginPass;

    @FXML
    private void handleLogin(ActionEvent event) {
        String user = txtLoginUser.getText();
        String pass = txtLoginPass.getText();

        // 1. Kiểm tra xem người dùng đã nhập đủ thông tin chưa
        if (user.isEmpty() || pass.isEmpty()) {
            showAlert("Vui lòng nhập đầy đủ Tên đăng nhập và Mật khẩu!");
            return;
        }

        // 2. Kiểm tra xem tài khoản có tồn tại trong bộ nhớ tạm chưa
        if (!Main.userDatabase.containsKey(user)) {
            // NẾU CHƯA CÓ TÀI KHOẢN
            showAlert("Chưa có tài khoản!");
            return;
        }

        // 3. Nếu tài khoản có tồn tại, kiểm tra xem mật khẩu có khớp không
        if (!Main.userDatabase.get(user).equals(pass)) {
            // NẾU SAI MẬT KHẨU
            showAlert("Mật khẩu không chính xác!");
            return;
        }

        // 4. Vượt qua hết các lỗi trên -> Đăng nhập thành công!
        try {
            // Lấy vai trò của user này từ bộ nhớ tạm
            String role = Main.userRoles.get(user);

            // Nếu là Bidder thì mở bidder.fxml, nếu là Seller thì mở seller.fxml
            String NEXT_SCREEN_FXML = role.equals("Bidder") ? "bidder.fxml" : "seller.fxml";

            Parent root = FXMLLoader.load(getClass().getResource(NEXT_SCREEN_FXML));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Trang chủ - " + role);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Lỗi: Không tải được giao diện trang chủ!");
        }
    }

    @FXML
    private void goToRegister(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("deptrai2.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Đăng ký");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Thông báo");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}