package com.example.dangky;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(com.example.dangky.Main.class, args);
    }
}
