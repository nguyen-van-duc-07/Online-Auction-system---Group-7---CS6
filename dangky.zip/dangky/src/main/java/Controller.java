package com.example.dangky;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML private TextField txtUser;
    @FXML private PasswordField txtPass;
    @FXML private PasswordField txtConfirm;
    @FXML private ChoiceBox<String> choiceRole;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        choiceRole.getItems().addAll("Bidder", "Seller");
        choiceRole.setValue("Bidder");
    }

    @FXML
    private void handleRegister(ActionEvent event) {
        String user = txtUser.getText();
        String pass = txtPass.getText();
        String confirm = txtConfirm.getText();
        String role = choiceRole.getValue();

        if (user.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
            show("Vui lòng nhập đầy đủ thông tin!");
            return;
        }

        if (!pass.equals(confirm)) {
            show("Mật khẩu xác nhận không khớp!");
            return;
        }

        // QUAN TRỌNG: Lưu tài khoản và mật khẩu
        Main.userDatabase.put(user, pass);

        // QUAN TRỌNG: Lưu tài khoản và Vai trò (để lúc đăng nhập biết đường chuyển trang)
        Main.userRoles.put(user, role);

        show("Đăng ký thành công với vai trò: " + role);

        try {
            Parent root = FXMLLoader.load(getClass().getResource("deptrai1.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Đăng nhập");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void show(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Thông báo");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}