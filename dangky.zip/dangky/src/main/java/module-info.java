module com.example.dangky {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.dangky to javafx.fxml;
    exports com.example.dangky;
}